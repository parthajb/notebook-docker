
from notebook.auth import passwd

c.NotebookApp.password = passwd('password')

c.NotebookApp.quit_button = False

